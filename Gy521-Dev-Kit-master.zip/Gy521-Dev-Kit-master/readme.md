### GY521 dev tool kit

For GY521 breakout board with MPU6050 Accelerometer, Gyroscope and temperature sensor.

Some tools that help test and develop with an Arduino and GY521


Uses https://processing.org app for visualisations

