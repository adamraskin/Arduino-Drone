Code originally by Odis Harkins
http://odisharkins.com/robotics/gyro-arduino-processing/

This Processing (Install https://processing.org) sketch allows you to visualise in real time the data output from the GY521.

- Connect the GY521 to an Arduino. Upload the serial data send sketch found in this repo. 

- Download and install Processing https://processing.org

- Open and run this sketch


