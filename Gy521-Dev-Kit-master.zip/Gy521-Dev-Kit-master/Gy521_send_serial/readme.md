### GY521 send data to serial interface
Original version by arduino.cc user "Krodal".
// June 2012
// Open Source / Public Domain



Upload this code to an Arduino. Tested on an Uno but should work on others. 

Test that it's working by opening the Serial Monitor in the Arduino IDE